package org.itstack.demo.design;

public interface OrderAdapterService {

    boolean isFirst(String uId);

}
