package org.itstack.demo.design.coupon;

public class CouponInfo {
}
