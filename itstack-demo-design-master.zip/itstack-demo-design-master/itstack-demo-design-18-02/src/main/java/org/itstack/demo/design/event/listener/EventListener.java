package org.itstack.demo.design.event.listener;

import org.itstack.demo.design.LotteryResult;

public interface EventListener {

    void doEvent(LotteryResult result);

}
